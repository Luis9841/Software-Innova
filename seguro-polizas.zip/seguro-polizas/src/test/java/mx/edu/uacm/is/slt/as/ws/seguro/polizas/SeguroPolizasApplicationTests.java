package mx.edu.uacm.is.slt.as.ws.seguro.polizas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeguroPolizasApplicationTests {

	@Test
	void contextLoads() {
	}

}
